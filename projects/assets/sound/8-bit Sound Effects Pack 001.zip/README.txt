Feel free to use these SFX for your games.
You do not need permission to use for non commercial / commercial uses, just please credit me as @Shades

https://soundcloud.com/noshades

The pack contains (46 wav files) :
5 coin sound effects
3 exit sound effects
5 explosion sound effects
3 flying sound effects
6 hit sound effects
4 jump sound effects
3 powerup sound effects
3 shoot sound effects
4 talk sound effects
3 error sound effects
